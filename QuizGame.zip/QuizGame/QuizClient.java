	package QuizGame;
	
	import java.util.Scanner;
	
	public class QuizClient implements Runnable {
		QuizBank[] questionArray = new QuizBank[5];
		int[] responseArray = new int[5];
		
		public static void main(String[] args) {
			Thread t = new Thread(new QuizClient());
			t.start();
			
			
		}
		public void setQuestions(){
			questionArray[0] = new QuizBank("Which of the following correctly shows the hierarchy of arithmetic operations in C z = x + y * z / 4 % 2 - 1?", "* / % + - =", "= * / % + -", "/ * % - + =", "* % / - + =", 1);
			questionArray[1] = new QuizBank("Which of the following function sets first n characters of a string to a given character?", "strinit()", "strnset()", "strset()", "strcset()", 2);
			questionArray[2] = new QuizBank("Which of the following function is more appropriate for reading in a multi-word string?", "printf", "scanf", "sanf;", "gets();", 4);
			questionArray[3] =new  QuizBank("The library function used to find the last occurrence of a character in a string is", "strnstr()", "laststr()", "strrchr()", "strstr()", 3);
			questionArray[4] = new QuizBank("Which of the following function is used to find the first occurrence of a given string in another string?", "strchr()", "strrchr()", "strstr()", "strnset()", 3);
			
		}
		public void printCurQuestion(QuizBank curQuestion,int i){
			System.out.println((i+1) +"."+curQuestion.getQuestion());
			System.out.println("1."+ curQuestion.getOption1()+"\t\t"+"2. "+curQuestion.getOption2()+"\n"+"3."+curQuestion.getOption3()+"\t\t"+"4."+curQuestion.getOption4());
			
		}
	
		
		public int evaluate() {
			int score = 0;
			for (int i = 0; i < questionArray.length; i++) {
				QuizBank curQuestion = questionArray[i];
				if (curQuestion.getCorrectOption() == responseArray[i]){
					score++;
				}
			}
			return score;
			
		}
		public int  numberOfAttemtedQuestions() {
			int ct = 0;
			for (int i = 0; i < questionArray.length; i++) {
				if (responseArray[i] !=  0){
					ct++;
				}
			}
			return ct;
		}
		public void printResult(){
			System.out.println("************Results****************");
			System.out.println("Your Score : "+ evaluate());
			System.out.println("Total marks : "+ questionArray.length);
			System.out.println("Total number of Questions : "+ questionArray.length);
			System.out.println("Total number of attemted Questions : "+ numberOfAttemtedQuestions());
		}
		@Override
		public void run() {
			// TODO Auto-generated method stub
			setQuestions();
			for (int i = 0; i < questionArray.length; i++) {
				QuizBank curQuestion = questionArray[i];
				printCurQuestion(curQuestion, i);
				try {
					
					
					Scanner sc = new Scanner(System.in);
					int getOption = sc.nextInt();
					if (getOption>=1 && getOption<=4) {
						responseArray[i] = getOption;
						throw new InterruptedException();
					}
					else{
						responseArray[i] = 0;
					}
					
					
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
				//	System.out.println("Timer interrupted");
					continue;
				}
				
			}
			printResult();
			
		}
		
		
	}
