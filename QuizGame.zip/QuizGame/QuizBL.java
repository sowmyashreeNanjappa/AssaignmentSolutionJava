package QuizGame;

public class QuizBL  {

	

}
