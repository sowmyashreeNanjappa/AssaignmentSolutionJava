package synonym;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

public class synonymDict {

	public static void main(String[] args) {
		HashMap<String, String[]> list = new HashMap<String,String[]>();
		list.put("war", new String[]{"battle","enimity"});
		list.put("Outgoing",new String[]{"Friendly","Sociable"} );
		list.put("Mean", new String[]{"Unfriendly","unpleasent"});
		list.put("Lazy", new String[]{"Idle","Lackadaisical"});
		list.put("Honest", new String[]{"Honorable","Fair"});
		System.out.println("Enter the word for which you want synonym : ");
		Scanner sc = new Scanner(System.in);
		String key = sc.next();
		if (list.containsKey(key)) {
			String[] array = list.get(key);
			System.out.println("Synonym are : ");
			for (String string : array) {
				System.out.println(string);
			}
		} else {
			System.out.println("key not found");
		}
		
		
		
		
	}
}
