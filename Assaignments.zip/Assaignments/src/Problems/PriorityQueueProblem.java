package Problems;

import java.util.PriorityQueue;

public class PriorityQueueProblem {
	public static void main(String[] args) {
		
	 PriorityQueue<Device> deviceList = new PriorityQueue<>(10, new SortingComparator.sortByDecID());
	 deviceList.add(new Device("mobile",13000));
	 deviceList.add(new Device("laptop", 35000));
	 deviceList.add(new Device("Bike", 50000));
	 deviceList.add(new Device("Mouse", 2000));
	 System.out.println("My Device list in decreasing order of price is  : \n");

	 for (Device device : deviceList) {
		System.out.println(device.getName() + "\t\t"+device.getRate());
	}
	
	}
}
